import userConfig from "../config.json" with { type: "json" };

// Export the user configuration directly
export const config = userConfig;
